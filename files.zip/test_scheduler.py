import sys
from datetime import date, time, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import exporters  # noqa: E402
import scheduler as sch  # noqa: E402
import storage  # noqa: E402

START = date(2026, 10, 5)  # a Monday


def subjects():
    return [
        sch.Subject("Maths", START + timedelta(days=10), 5, ["A", "B", "C"], ["C"]),
        sch.Subject("Python", START + timedelta(days=6), 2, ["X", "Y"]),
        sch.Subject("Stats", START + timedelta(days=14), 3, []),
    ]


def cfg(**kw):
    return sch.PlannerConfig(start=START, **kw)


def hours_by_day(plan):
    out = {}
    for s in plan:
        out[s.date] = out.get(s.date, 0) + s.hours
    return out


def test_no_study_on_or_after_exam_day():
    subs = subjects()
    plan = sch.generate_plan(subs, cfg())
    exam = {s.name: s.exam_date for s in subs}
    assert plan
    assert all(s.date < exam[s.subject] for s in plan)


def test_daily_hours_match_capacity():
    c = cfg(weekday_hours=3, weekend_hours=5)
    plan = sch.generate_plan(subjects(), c)
    for day, h in hours_by_day(plan).items():
        cap = c.weekend_hours if day.weekday() >= 5 else c.weekday_hours
        assert h == cap


def test_max_subjects_per_day():
    plan = sch.generate_plan(subjects(), cfg(max_subjects_per_day=2))
    per_day = {}
    for s in plan:
        per_day.setdefault(s.date, set()).add(s.subject)
    assert max(len(v) for v in per_day.values()) <= 2


def test_sessions_never_longer_than_block():
    plan = sch.generate_plan(subjects(), cfg(weekday_hours=8, weekend_hours=10, max_subjects_per_day=1))
    assert all(s.hours <= sch.MAX_BLOCK_HOURS for s in plan)


def test_revision_only_inside_window():
    subs = subjects()
    plan = sch.generate_plan(subs, cfg(revision_days=2))
    exam = {s.name: s.exam_date for s in subs}
    for s in plan:
        days_left = (exam[s.subject] - s.date).days
        assert (s.kind == sch.KIND_REVISION) == (days_left <= 2)


def test_days_off_respected():
    off = START + timedelta(days=2)
    plan = sch.generate_plan(subjects(), cfg(days_off=[off]))
    assert all(s.date != off for s in plan)


def test_harder_subject_gets_more_time_same_exam():
    exam = START + timedelta(days=10)
    subs = [sch.Subject("Hard", exam, 5), sch.Subject("Easy", exam, 1)]
    plan = sch.generate_plan(subs, cfg())
    h = {n: sum(s.hours for s in plan if s.subject == n) for n in ("Hard", "Easy")}
    assert h["Hard"] > h["Easy"]


def test_closer_exam_gets_more_time_same_difficulty():
    subs = [sch.Subject("Soon", START + timedelta(days=4), 3), sch.Subject("Later", START + timedelta(days=12), 3)]
    plan = sch.generate_plan(subs, cfg())
    first_days = [s for s in plan if s.date < START + timedelta(days=4)]
    h = {n: sum(s.hours for s in first_days if s.subject == n) for n in ("Soon", "Later")}
    assert h["Soon"] > h["Later"]


def test_weak_topics_scheduled_more_often():
    subs = [sch.Subject("Maths", START + timedelta(days=20), 3, ["A", "B", "C", "D"], ["C"])]
    plan = sch.generate_plan(subs, cfg(revision_days=0, max_subjects_per_day=1))
    topics = [s.topic for s in plan]
    assert topics.count("C") >= 2 * topics.count("A") or topics.count("C") > topics.count("A")


def test_no_topics_uses_placeholder():
    plan = sch.generate_plan([sch.Subject("Stats", START + timedelta(days=3), 3)], cfg())
    assert {s.topic for s in plan if s.kind == sch.KIND_STUDY} <= {"General study"}


def test_replan_moves_missed_work_forward():
    subs = subjects()
    c = cfg()
    plan = sch.generate_plan(subs, c)
    today = START + timedelta(days=3)
    missed_before = sch.missed_sessions(plan, today)
    assert missed_before
    new = sch.replan(plan, subs, c, today)

    assert sch.missed_sessions(new, today) == []                      # nothing left "missed"
    assert all(s.rescheduled for s in new if s.date < today)          # history flagged
    assert all(s.date >= today for s in new if not s.rescheduled)     # new work starts today
    # replanning again must not double count the same backlog
    again = sch.replan(new, subs, c, today)
    assert round(sch.progress_summary(again)["total"], 3) == round(sch.progress_summary(new)["total"], 3)


def test_replan_schedules_missed_topics_first():
    subs = [sch.Subject("Maths", START + timedelta(days=12), 3, ["A", "B", "C", "D", "E", "F"])]
    c = cfg(max_subjects_per_day=1, revision_days=0)
    plan = sch.generate_plan(subs, c)
    today = START + timedelta(days=3)
    missed_topics = [s.topic for s in sch.missed_sessions(plan, today)]
    new = sch.replan(plan, subs, c, today)
    first = next(s for s in new if not s.rescheduled)
    assert first.topic == missed_topics[0]


def test_replan_keeps_done_sessions_and_their_hours():
    subs = subjects()
    c = cfg()
    plan = sch.generate_plan(subs, c)
    today = START + timedelta(days=2)
    todays = [s for s in plan if s.date == today]
    todays[0].done = True
    new = sch.replan(plan, subs, c, today)
    assert any(s.id == todays[0].id and s.done for s in new)
    assert hours_by_day([s for s in new if not s.rescheduled])[today] <= c.weekday_hours + 1e-9


def test_progress_summary():
    plan = sch.generate_plan(subjects(), cfg())
    plan[0].done = True
    p = sch.progress_summary(plan)
    assert p["done"] == plan[0].hours
    assert abs(p["total"] - sum(s.hours for s in plan)) < 1e-9


def test_parse_list_and_validation():
    assert sch.parse_list("a, b;  A ,, c\nd") == ["a", "b", "c", "d"]
    rows = [
        {"name": "Maths", "exam_date": START + timedelta(days=5), "difficulty": 9, "topics": "a,b", "weak_topics": ""},
        {"name": "maths", "exam_date": START + timedelta(days=6), "difficulty": 3},
        {"name": "Old", "exam_date": START, "difficulty": 3},
        {"name": "NoDate", "exam_date": None},
        {"name": "", "exam_date": None},  # blank row ignored
    ]
    subs, errors = sch.subjects_from_rows(rows, START)
    assert [s.name for s in subs] == ["Maths"]
    assert subs[0].difficulty == 5  # clamped
    assert len(errors) == 3


def test_storage_roundtrip():
    subs, c = subjects(), cfg(days_off=[START + timedelta(days=1)])
    plan = sch.generate_plan(subs, c)
    plan[0].done = True
    s2, c2, p2 = storage.load_state(storage.dump_state(subs, c, plan))
    assert c2 == c and s2 == subs and p2 == plan


def test_storage_rejects_garbage():
    for bad in ("not json", "{}", '{"app": "smart-study-planner"}'):
        try:
            storage.load_state(bad)
        except ValueError:
            continue
        raise AssertionError("expected ValueError")


def test_exports():
    subs = subjects()
    plan = sch.generate_plan(subs, cfg())
    csv = exporters.sessions_to_csv(plan)
    assert csv.splitlines()[0] == "Date,Day,Subject,Topic,Type,Hours,Done"
    ics = exporters.sessions_to_ics(plan, subs, time(18, 0))
    assert ics.startswith("BEGIN:VCALENDAR") and ics.rstrip().endswith("END:VCALENDAR")
    assert ics.count("BEGIN:VEVENT") == len(plan) + len(subs)
    assert "SUMMARY:EXAM: Maths" in ics
