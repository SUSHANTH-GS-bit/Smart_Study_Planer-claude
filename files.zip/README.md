# 📚 Smart Study Planner

Enter your subjects, exam dates, difficulty and daily study hours. The app generates a **day-by-day revision
timetable** with a **progress checklist**, **auto-replanning** for missed days, charts, and exports.

Built with Python + Streamlit for the REVA *Abhinava* hackathon.

## Features
- Subject table: exam date, difficulty (1-5), topics, weak topics
- Smart scheduler: harder + closer exams get more time, revision window before each exam, weak topics studied twice
- Weekday / weekend hours, days off, max subjects per day
- Per-session checklist with live progress bars (overall + per subject)
- **Auto-replan**: missed sessions are moved forward, missed topics first, backlog subjects get extra weight
- Daily load chart + weekly heatmap
- Export: CSV, calendar `.ics` (Google/Outlook/Apple), JSON save file to resume later
- 19 automated tests

## Run locally
```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

## Run tests
```bash
pip install pytest
pytest -q
```

## Push to GitHub
```bash
git init
git add .
git commit -m "Smart Study Planner"
git branch -M main
git remote add origin https://github.com/<your-username>/smart-study-planner.git
git push -u origin main
```

## Deploy (free) on Streamlit Community Cloud
1. Go to https://share.streamlit.io and sign in with GitHub.
2. Click **Create app**, choose your repo, branch `main`, main file `app.py`.
3. Click **Deploy**. You get a public link to show the judges.

Optional: set the environment variable `STUDY_PLANNER_TZ` (default `Asia/Kolkata`) under **Advanced settings → Secrets/Env**
if you need another timezone for "today".

### Docker (alternative)
```bash
docker build -t study-planner .
docker run -p 8501:8501 study-planner
```

## Project structure
```
app.py            Streamlit UI (Setup, Timetable, Progress, Export tabs)
scheduler.py      Scheduling + replanning engine (pure Python, no UI)
exporters.py      CSV and .ics export
storage.py        Save / load progress as JSON
tests/            Unit tests + app smoke test
requirements.txt  Dependencies
.streamlit/       Theme and server config
Dockerfile        Container deployment
```

## Notes
- Streamlit Cloud has no permanent disk. Progress lives in the browser session; use **Save progress (JSON)** in the
  Export tab and upload it from the sidebar to resume.
- Demo tip: click **Load demo subjects → Generate timetable**, tick a few sessions, then change the sidebar hours or
  use **Auto-replan** to show the plan adapting live.
