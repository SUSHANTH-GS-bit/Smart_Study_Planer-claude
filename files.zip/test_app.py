"""Smoke test: the Streamlit app starts, generates a plan and renders every tab."""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from streamlit.testing.v1 import AppTest  # noqa: E402


def test_app_generates_and_renders():
    at = AppTest.from_file(str(ROOT / "app.py"), default_timeout=60).run()
    assert not at.exception

    gen = next(b for b in at.button if "Generate timetable" in b.label)
    gen.click().run()
    assert not at.exception
    assert at.session_state["plan"]

    # tick a checkbox -> progress updates
    boxes = [c for c in at.checkbox if c.key and c.key.startswith("chk_")]
    assert boxes
    plan_before = sum(s.done for s in at.session_state["plan"])
    boxes[0].check().run()
    assert not at.exception
    assert sum(s.done for s in at.session_state["plan"]) == plan_before + 1
