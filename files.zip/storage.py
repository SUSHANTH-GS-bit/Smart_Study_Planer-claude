"""Save / load the whole planner state as a JSON file.

Streamlit Community Cloud has no permanent disk, so progress is kept in the
browser session and can be downloaded as JSON and re-uploaded later.
"""
from __future__ import annotations

import json
from datetime import datetime
from typing import List, Sequence, Tuple

from scheduler import PlannerConfig, Session, Subject

APP_ID = "smart-study-planner"
FORMAT_VERSION = 1


def dump_state(subjects: Sequence[Subject], cfg: PlannerConfig, sessions: Sequence[Session]) -> str:
    payload = {
        "app": APP_ID,
        "version": FORMAT_VERSION,
        "saved_at": datetime.now().isoformat(timespec="seconds"),
        "config": cfg.to_dict(),
        "subjects": [s.to_dict() for s in subjects],
        "sessions": [s.to_dict() for s in sessions],
    }
    return json.dumps(payload, indent=2)


def load_state(text: str) -> Tuple[List[Subject], PlannerConfig, List[Session]]:
    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ValueError("file is not valid JSON") from exc
    if not isinstance(data, dict) or data.get("app") != APP_ID:
        raise ValueError("this is not a Smart Study Planner save file")
    try:
        cfg = PlannerConfig.from_dict(data["config"])
        subjects = [Subject.from_dict(d) for d in data["subjects"]]
        sessions = [Session.from_dict(d) for d in data["sessions"]]
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError(f"save file is incomplete or corrupted ({exc})") from exc
    return subjects, cfg, sessions
