"""Export the timetable as CSV or an .ics calendar file."""
from __future__ import annotations

import hashlib
from collections import defaultdict
from datetime import datetime, time, timedelta, timezone
from typing import Iterable, Sequence

import pandas as pd

from scheduler import Session, Subject


def sessions_to_df(sessions: Iterable[Session]) -> pd.DataFrame:
    rows = [
        {
            "Date": s.date,
            "Day": s.date.strftime("%a"),
            "Subject": s.subject,
            "Topic": s.topic,
            "Type": s.kind,
            "Hours": s.hours,
            "Done": "Yes" if s.done else ("Moved" if s.rescheduled else "No"),
        }
        for s in sessions
    ]
    return pd.DataFrame(rows, columns=["Date", "Day", "Subject", "Topic", "Type", "Hours", "Done"])


def sessions_to_csv(sessions: Iterable[Session]) -> str:
    return sessions_to_df(sessions).to_csv(index=False)


def _escape(text: str) -> str:
    return (
        text.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")
    )


def _fold(line: str, limit: int = 73) -> str:
    """RFC 5545 line folding (continuation lines start with a space)."""
    if len(line) <= limit:
        return line
    parts = [line[:limit]]
    rest = line[limit:]
    while rest:
        parts.append(" " + rest[: limit - 1])
        rest = rest[limit - 1:]
    return "\r\n".join(parts)


def sessions_to_ics(
    sessions: Iterable[Session],
    subjects: Sequence[Subject],
    day_start: time = time(18, 0),
) -> str:
    """Build an iCalendar file. Sessions on a day are placed back-to-back from `day_start`.
    Times are 'floating' (local time of whoever imports the file). Exams are all-day events.
    """
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    lines = [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        "PRODID:-//Smart Study Planner//EN",
        "CALSCALE:GREGORIAN",
        "METHOD:PUBLISH",
    ]

    by_day = defaultdict(list)
    for s in sessions:
        if not s.rescheduled:
            by_day[s.date].append(s)

    for day in sorted(by_day):
        cursor = datetime.combine(day, day_start)
        for s in by_day[day]:
            end = cursor + timedelta(hours=s.hours)
            lines += [
                "BEGIN:VEVENT",
                f"UID:{s.id}@smart-study-planner",
                f"DTSTAMP:{stamp}",
                f"DTSTART:{cursor:%Y%m%dT%H%M%S}",
                f"DTEND:{end:%Y%m%dT%H%M%S}",
                f"SUMMARY:{_escape(f'{s.subject}: {s.topic}')}",
                f"DESCRIPTION:{_escape(f'{s.kind} session ({s.hours:g} h)')}",
                "END:VEVENT",
            ]
            cursor = end

    for sub in subjects:
        lines += [
            "BEGIN:VEVENT",
            f"UID:exam-{hashlib.md5(f'{sub.name}{sub.exam_date}'.encode()).hexdigest()[:12]}@smart-study-planner",
            f"DTSTAMP:{stamp}",
            f"DTSTART;VALUE=DATE:{sub.exam_date:%Y%m%d}",
            f"DTEND;VALUE=DATE:{sub.exam_date + timedelta(days=1):%Y%m%d}",
            f"SUMMARY:{_escape('EXAM: ' + sub.name)}",
            "END:VEVENT",
        ]

    lines.append("END:VCALENDAR")
    return "\r\n".join(_fold(l) for l in lines) + "\r\n"
