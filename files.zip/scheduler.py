"""Core scheduling engine for the Smart Study Planner.

Pure Python (no Streamlit imports) so it can be unit-tested and reused.

How the plan is built
---------------------
For every day between the start date and the last exam:

1. Work out how many 30-minute slots the student has that day
   (weekday / weekend hours, minus days off, minus anything already done).
2. For every subject whose exam is still ahead, compute a weight::

       weight = difficulty * (1 + 7 / days_left)      # closer + harder = more time
       weight *= 1.5   if the subject is in its revision window
       weight *= 1 + backlog_hours / 10   (max x2)     # missed work gets priority

3. Keep the top N subjects (so a day is never split into tiny pieces) and
   share the day's slots between them using the largest-remainder method.
4. Turn each subject's share into sessions of at most 2 hours, each with a topic.
   Weak topics are studied twice, and revision days cycle through weak topics first.
"""
from __future__ import annotations

import math
import re
import uuid
from dataclasses import dataclass, field, replace
from datetime import date, datetime, timedelta
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

SLOT_HOURS = 0.5            # smallest unit of study time
MAX_BLOCK_HOURS = 2.0       # longest single session on one topic
MAX_BACKLOG_BOOST_HOURS = 10.0
KIND_STUDY = "Study"
KIND_REVISION = "Revision"


# --------------------------------------------------------------------------- #
# Data classes
# --------------------------------------------------------------------------- #
@dataclass
class Subject:
    name: str
    exam_date: date
    difficulty: int = 3
    topics: List[str] = field(default_factory=list)
    weak_topics: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "exam_date": self.exam_date.isoformat(),
            "difficulty": self.difficulty,
            "topics": list(self.topics),
            "weak_topics": list(self.weak_topics),
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Subject":
        return cls(
            name=d["name"],
            exam_date=date.fromisoformat(d["exam_date"]),
            difficulty=int(d.get("difficulty", 3)),
            topics=list(d.get("topics", [])),
            weak_topics=list(d.get("weak_topics", [])),
        )


@dataclass
class PlannerConfig:
    start: date
    weekday_hours: float = 3.0
    weekend_hours: float = 5.0
    revision_days: int = 2
    max_subjects_per_day: int = 3
    days_off: List[date] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "start": self.start.isoformat(),
            "weekday_hours": self.weekday_hours,
            "weekend_hours": self.weekend_hours,
            "revision_days": self.revision_days,
            "max_subjects_per_day": self.max_subjects_per_day,
            "days_off": [d.isoformat() for d in self.days_off],
        }

    @classmethod
    def from_dict(cls, d: dict) -> "PlannerConfig":
        return cls(
            start=date.fromisoformat(d["start"]),
            weekday_hours=float(d.get("weekday_hours", 3.0)),
            weekend_hours=float(d.get("weekend_hours", 5.0)),
            revision_days=int(d.get("revision_days", 2)),
            max_subjects_per_day=int(d.get("max_subjects_per_day", 3)),
            days_off=[date.fromisoformat(x) for x in d.get("days_off", [])],
        )


@dataclass
class Session:
    id: str
    date: date
    subject: str
    topic: str
    hours: float
    kind: str = KIND_STUDY
    done: bool = False
    rescheduled: bool = False   # True = missed and moved to a later day by replan

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "date": self.date.isoformat(),
            "subject": self.subject,
            "topic": self.topic,
            "hours": self.hours,
            "kind": self.kind,
            "done": self.done,
            "rescheduled": self.rescheduled,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Session":
        return cls(
            id=d["id"],
            date=date.fromisoformat(d["date"]),
            subject=d["subject"],
            topic=d["topic"],
            hours=float(d["hours"]),
            kind=d.get("kind", KIND_STUDY),
            done=bool(d.get("done", False)),
            rescheduled=bool(d.get("rescheduled", False)),
        )


# --------------------------------------------------------------------------- #
# Input parsing / validation
# --------------------------------------------------------------------------- #
def parse_list(text) -> List[str]:
    """'a, b; c' -> ['a', 'b', 'c'] (trimmed, de-duplicated, order kept)."""
    if text is None:
        return []
    if isinstance(text, (list, tuple)):
        items = [str(x) for x in text]
    else:
        items = re.split(r"[,;\n]+", str(text))
    out, seen = [], set()
    for item in items:
        item = item.strip()
        if item and item.lower() not in seen:
            seen.add(item.lower())
            out.append(item)
    return out


def subjects_from_rows(rows: Iterable[dict], start: date) -> Tuple[List[Subject], List[str]]:
    """Validate raw table rows and build Subject objects.

    Each row is a dict with keys: name, exam_date, difficulty, topics, weak_topics.
    Completely blank rows are ignored. Returns (subjects, error_messages).
    """
    subjects: List[Subject] = []
    errors: List[str] = []
    seen = set()
    for i, row in enumerate(rows, start=1):
        name = str(row.get("name") or "").strip()
        exam = row.get("exam_date")
        if isinstance(exam, datetime):
            exam = exam.date()
        topics = parse_list(row.get("topics"))
        weak = parse_list(row.get("weak_topics"))
        if not name and exam is None and not topics and not weak:
            continue  # blank row
        label = f"Row {i}" + (f" ({name})" if name else "")
        if not name:
            errors.append(f"{label}: subject name is missing.")
            continue
        if name.lower() in seen:
            errors.append(f"{label}: duplicate subject name.")
            continue
        seen.add(name.lower())
        if exam is None:
            errors.append(f"{label}: exam date is missing.")
            continue
        if exam <= start:
            errors.append(f"{label}: exam date must be after the plan start date ({start:%d %b %Y}).")
            continue
        try:
            difficulty = int(row.get("difficulty") or 3)
        except (TypeError, ValueError):
            difficulty = 3
        difficulty = min(5, max(1, difficulty))
        subjects.append(Subject(name, exam, difficulty, topics, weak))
    return subjects, errors


# --------------------------------------------------------------------------- #
# Plan generation
# --------------------------------------------------------------------------- #
class _TopicPicker:
    """Hands out topics for one subject, one session at a time."""

    def __init__(self, subject: Subject, carry: Sequence[str], completed: set):
        base = list(subject.topics) + [w for w in subject.weak_topics if w not in subject.topics]
        remaining = [t for t in base if t not in completed]
        carry_unique: List[str] = []
        for t in carry:
            if t not in carry_unique:
                carry_unique.append(t)
        if remaining or carry_unique:
            study = carry_unique + [t for t in remaining if t not in carry_unique] + list(subject.weak_topics)
        else:  # whole syllabus already covered -> cycle through it again
            study = base + list(subject.weak_topics)
        review = list(subject.weak_topics) + [t for t in base if t not in subject.weak_topics]
        self._study = study or ["General study"]
        self._review = review or ["Full syllabus revision"]
        self._si = 0
        self._ri = 0

    def next(self, revision: bool) -> str:
        if revision:
            topic = self._review[self._ri % len(self._review)]
            self._ri += 1
        else:
            topic = self._study[self._si % len(self._study)]
            self._si += 1
        return topic


def _new_id() -> str:
    return uuid.uuid4().hex[:10]


def _weight(subject: Subject, days_left: int, revision: bool, backlog: float) -> float:
    w = subject.difficulty * (1.0 + 7.0 / max(days_left, 1))
    if revision:
        w *= 1.5
    w *= 1.0 + min(backlog, MAX_BACKLOG_BOOST_HOURS) / MAX_BACKLOG_BOOST_HOURS
    return w


def _apportion(total: int, weights: Sequence[float]) -> List[int]:
    """Split `total` integer slots proportionally (largest-remainder method)."""
    s = sum(weights)
    if total <= 0 or s <= 0:
        return [0] * len(weights)
    raw = [total * w / s for w in weights]
    base = [int(math.floor(r)) for r in raw]
    leftover = total - sum(base)
    order = sorted(range(len(weights)), key=lambda i: raw[i] - base[i], reverse=True)
    for i in order[:leftover]:
        base[i] += 1
    return base


def day_capacity_slots(day: date, cfg: PlannerConfig, used_hours: float = 0.0) -> int:
    """Number of free 30-minute slots on `day`."""
    if day in set(cfg.days_off):
        return 0
    hours = cfg.weekend_hours if day.weekday() >= 5 else cfg.weekday_hours
    hours = max(0.0, hours - used_hours)
    return int(hours / SLOT_HOURS + 1e-9)


def available_hours(cfg: PlannerConfig, until: date) -> float:
    """Total study hours between cfg.start and the day before `until`."""
    total, day = 0.0, cfg.start
    while day < until:
        total += day_capacity_slots(day, cfg) * SLOT_HOURS
        day += timedelta(days=1)
    return total


def generate_plan(
    subjects: Sequence[Subject],
    cfg: PlannerConfig,
    *,
    backlog_hours: Optional[Dict[str, float]] = None,
    carry_topics: Optional[Dict[str, List[str]]] = None,
    completed_topics: Optional[Dict[str, set]] = None,
    used_hours: Optional[Dict[date, float]] = None,
) -> List[Session]:
    """Create a day-by-day list of study sessions. See module docstring."""
    backlog_hours = backlog_hours or {}
    carry_topics = carry_topics or {}
    completed_topics = completed_topics or {}
    used_hours = used_hours or {}

    active = [s for s in subjects if s.exam_date > cfg.start]
    if not active:
        return []
    last_day = max(s.exam_date for s in active) - timedelta(days=1)
    pickers = {
        s.name: _TopicPicker(s, carry_topics.get(s.name, []), completed_topics.get(s.name, set()))
        for s in active
    }

    sessions: List[Session] = []
    day = cfg.start
    while day <= last_day:
        slots = day_capacity_slots(day, cfg, used_hours.get(day, 0.0))
        if slots > 0:
            todays = []
            for s in active:
                days_left = (s.exam_date - day).days
                if days_left < 1:      # exam is today or already over
                    continue
                revision = days_left <= cfg.revision_days
                todays.append((s, revision, _weight(s, days_left, revision, backlog_hours.get(s.name, 0.0))))
            todays.sort(key=lambda x: x[2], reverse=True)
            todays = todays[: max(1, cfg.max_subjects_per_day)]
            if todays:
                alloc = _apportion(slots, [w for _, _, w in todays])
                for (s, revision, _), k in zip(todays, alloc):
                    hours = k * SLOT_HOURS
                    while hours > 1e-9:
                        chunk = min(hours, MAX_BLOCK_HOURS)
                        sessions.append(
                            Session(
                                id=_new_id(),
                                date=day,
                                subject=s.name,
                                topic=pickers[s.name].next(revision),
                                hours=chunk,
                                kind=KIND_REVISION if revision else KIND_STUDY,
                            )
                        )
                        hours -= chunk
        day += timedelta(days=1)
    return sessions


# --------------------------------------------------------------------------- #
# Progress + replanning
# --------------------------------------------------------------------------- #
def missed_sessions(sessions: Iterable[Session], today: date) -> List[Session]:
    return [s for s in sessions if s.date < today and not s.done and not s.rescheduled]


def progress_summary(sessions: Iterable[Session]) -> dict:
    live = [s for s in sessions if not s.rescheduled]
    by_subject: Dict[str, Tuple[float, float]] = {}
    for s in live:
        done, total = by_subject.get(s.subject, (0.0, 0.0))
        by_subject[s.subject] = (done + (s.hours if s.done else 0.0), total + s.hours)
    return {
        "total": sum(s.hours for s in live),
        "done": sum(s.hours for s in live if s.done),
        "by_subject": by_subject,
    }


def replan(
    sessions: Sequence[Session],
    subjects: Sequence[Subject],
    cfg: PlannerConfig,
    today: date,
) -> List[Session]:
    """Redistribute missed sessions over the remaining days.

    * Past sessions stay in the history; missed ones are flagged `rescheduled`.
    * Sessions already ticked off on/after today are kept (and use up that day's hours).
    * Everything else from today onwards is regenerated, with a weight boost
      for subjects that have a backlog and the missed topics scheduled first.
    """
    new_start = max(today, cfg.start)
    kept: List[Session] = []
    backlog: Dict[str, float] = {}
    carry: Dict[str, List[str]] = {}
    completed: Dict[str, set] = {}
    used: Dict[date, float] = {}

    for s in sessions:
        c = replace(s)
        if c.done and c.kind == KIND_STUDY:
            completed.setdefault(c.subject, set()).add(c.topic)
        if c.date < new_start:
            if not c.done and not c.rescheduled:
                c.rescheduled = True
                backlog[c.subject] = backlog.get(c.subject, 0.0) + c.hours
                if c.kind == KIND_STUDY:
                    carry.setdefault(c.subject, []).append(c.topic)
            kept.append(c)
        elif c.done:
            kept.append(c)
            used[c.date] = used.get(c.date, 0.0) + c.hours
        # future + not done -> dropped, will be regenerated

    new_cfg = replace(cfg, start=new_start)
    new_sessions = generate_plan(
        subjects,
        new_cfg,
        backlog_hours=backlog,
        carry_topics=carry,
        completed_topics=completed,
        used_hours=used,
    )
    return sorted(kept + new_sessions, key=lambda s: s.date)


# --------------------------------------------------------------------------- #
# Demo data
# --------------------------------------------------------------------------- #
def demo_subjects(start: date) -> List[Subject]:
    """Sample student with 4 subjects and exams over the next two weeks."""
    return [
        Subject("Data Structures", start + timedelta(days=9), 4,
                ["Arrays & Linked Lists", "Stacks & Queues", "Trees", "Graphs", "Sorting & Searching", "Hashing"],
                ["Graphs"]),
        Subject("Linear Algebra", start + timedelta(days=12), 5,
                ["Vectors & Matrices", "Determinants", "Vector Spaces", "Eigenvalues", "SVD"],
                ["Eigenvalues"]),
        Subject("Python for Data Science", start + timedelta(days=7), 2,
                ["NumPy", "Pandas", "Data Cleaning", "Visualization"], []),
        Subject("Probability & Statistics", start + timedelta(days=14), 3,
                ["Probability Basics", "Random Variables", "Distributions", "Hypothesis Testing", "Regression"],
                ["Hypothesis Testing"]),
    ]
