"""Smart Study Planner - Streamlit web app.

Run locally:   streamlit run app.py
"""
from __future__ import annotations

import os
from collections import defaultdict
from datetime import date, datetime, time, timedelta
from zoneinfo import ZoneInfo

import altair as alt
import pandas as pd
import streamlit as st

import exporters
import scheduler as sch
import storage

st.set_page_config(page_title="Smart Study Planner", page_icon="📚", layout="wide")

APP_TZ = os.environ.get("STUDY_PLANNER_TZ", "Asia/Kolkata")

SUBJECT_COL = "Subject"
EXAM_COL = "Exam date"
DIFF_COL = "Difficulty (1-5)"
TOPICS_COL = "Topics (comma-separated)"
WEAK_COL = "Weak topics (comma-separated)"
TABLE_COLUMNS = [SUBJECT_COL, EXAM_COL, DIFF_COL, TOPICS_COL, WEAK_COL]
WEEKDAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def today() -> date:
    """'Today' in the student's timezone (servers usually run in UTC)."""
    try:
        return datetime.now(ZoneInfo(APP_TZ)).date()
    except Exception:  # unknown tz name / missing tzdata
        return date.today()


def subjects_to_df(subjects) -> pd.DataFrame:
    return pd.DataFrame(
        [
            {
                SUBJECT_COL: s.name,
                EXAM_COL: s.exam_date,
                DIFF_COL: s.difficulty,
                TOPICS_COL: ", ".join(s.topics),
                WEAK_COL: ", ".join(s.weak_topics),
            }
            for s in subjects
        ],
        columns=TABLE_COLUMNS,
    )


def _blank(v) -> bool:
    try:
        return v is None or bool(pd.isna(v))
    except (TypeError, ValueError):
        return False


def _to_date(v):
    if _blank(v):
        return None
    try:
        return pd.to_datetime(v).date()
    except Exception:
        return None


def df_to_rows(df: pd.DataFrame) -> list:
    rows = []
    for rec in df.to_dict("records"):
        rows.append(
            {
                "name": "" if _blank(rec.get(SUBJECT_COL)) else str(rec[SUBJECT_COL]),
                "exam_date": _to_date(rec.get(EXAM_COL)),
                "difficulty": None if _blank(rec.get(DIFF_COL)) else rec[DIFF_COL],
                "topics": "" if _blank(rec.get(TOPICS_COL)) else str(rec[TOPICS_COL]),
                "weak_topics": "" if _blank(rec.get(WEAK_COL)) else str(rec[WEAK_COL]),
            }
        )
    return rows


def clear_checkbox_state() -> None:
    for k in [k for k in st.session_state.keys() if str(k).startswith("chk_")]:
        del st.session_state[k]


def init_state() -> None:
    ss = st.session_state
    t = today()
    ss.setdefault("cfg_start", t)
    ss.setdefault("cfg_weekday", 3.0)
    ss.setdefault("cfg_weekend", 5.0)
    ss.setdefault("cfg_rev", 2)
    ss.setdefault("cfg_maxsub", 3)
    ss.setdefault("cfg_off", [])
    ss.setdefault("cfg_time", time(18, 0))
    ss.setdefault("subjects_df", subjects_to_df(sch.demo_subjects(t)))
    ss.setdefault("editor_version", 0)
    ss.setdefault("plan", None)
    ss.setdefault("plan_subjects", [])
    ss.setdefault("plan_cfg", None)
    ss.setdefault("loaded_file", None)
    ss.setdefault("notice", None)


def _toggle(session_id: str) -> None:
    """Checkbox callback: runs before the rerun so progress bars update instantly."""
    for s in st.session_state.plan:
        if s.id == session_id:
            s.done = bool(st.session_state[f"chk_{session_id}"])
            break


def _load_demo() -> None:
    ss = st.session_state
    ss.subjects_df = subjects_to_df(sch.demo_subjects(ss.cfg_start))
    ss.editor_version += 1


def _reset_all() -> None:
    clear_checkbox_state()
    st.session_state.clear()


# --------------------------------------------------------------------------- #
# Sidebar
# --------------------------------------------------------------------------- #
def render_sidebar() -> sch.PlannerConfig:
    ss = st.session_state
    with st.sidebar:
        st.header("⚙️ Settings")

        # Resume a saved plan (must run before the widgets below are created)
        up = st.file_uploader("Resume saved progress (JSON)", type=["json"], key="upload")
        if up is None:
            ss.loaded_file = None
        elif ss.loaded_file != (up.name, up.size):
            try:
                subjects, cfg, sessions = storage.load_state(up.getvalue().decode("utf-8"))
            except Exception as exc:  # noqa: BLE001
                st.error(f"Could not load file: {exc}")
            else:
                ss.loaded_file = (up.name, up.size)
                ss.cfg_start = cfg.start
                ss.cfg_weekday = cfg.weekday_hours
                ss.cfg_weekend = cfg.weekend_hours
                ss.cfg_rev = cfg.revision_days
                ss.cfg_maxsub = cfg.max_subjects_per_day
                ss.cfg_off = list(cfg.days_off)
                ss.subjects_df = subjects_to_df(subjects)
                ss.editor_version += 1
                ss.plan = sessions
                ss.plan_subjects = subjects
                ss.plan_cfg = cfg
                clear_checkbox_state()
                st.success("Progress loaded ✔")

        st.divider()
        st.date_input("Plan starts on", key="cfg_start")
        st.slider("Study hours on weekdays", 0.0, 12.0, step=0.5, key="cfg_weekday")
        st.slider("Study hours on weekends", 0.0, 14.0, step=0.5, key="cfg_weekend")
        st.slider("Revision-only days before each exam", 0, 4, key="cfg_rev",
                  help="In this window the subject switches to revision mode and gets extra weight.")
        st.slider("Max subjects per day", 1, 4, key="cfg_maxsub",
                  help="Keeps each day focused instead of splitting it into tiny pieces.")

        base = today()
        options = sorted({base + timedelta(days=i) for i in range(-30, 151)} | set(ss.cfg_off))
        st.multiselect("Days off (no study)", options, key="cfg_off",
                       format_func=lambda d: d.strftime("%a, %d %b %Y"))

        st.divider()
        st.button("📥 Load demo subjects", on_click=_load_demo)
        st.button("🗑️ Reset everything", on_click=_reset_all)
        st.caption(f"Timezone: {APP_TZ} · today is {today():%a, %d %b %Y}")

    return sch.PlannerConfig(
        start=ss.cfg_start,
        weekday_hours=float(ss.cfg_weekday),
        weekend_hours=float(ss.cfg_weekend),
        revision_days=int(ss.cfg_rev),
        max_subjects_per_day=int(ss.cfg_maxsub),
        days_off=list(ss.cfg_off),
    )


# --------------------------------------------------------------------------- #
# Tab 1: Setup
# --------------------------------------------------------------------------- #
def render_setup(cfg: sch.PlannerConfig) -> None:
    ss = st.session_state
    st.subheader("1 · Enter your subjects")
    st.caption("One row per subject. Click the empty row at the bottom to add more. "
               "Weak topics are studied twice and revised first.")

    edited = st.data_editor(
        ss.subjects_df,
        key=f"subjects_editor_{ss.editor_version}",
        num_rows="dynamic",
        hide_index=True,
        column_config={
            SUBJECT_COL: st.column_config.TextColumn(width="medium"),
            EXAM_COL: st.column_config.DateColumn(format="DD MMM YYYY"),
            DIFF_COL: st.column_config.NumberColumn(min_value=1, max_value=5, step=1, default=3, format="%d",
                                                    help="5 = hardest. Harder subjects get more time."),
            TOPICS_COL: st.column_config.TextColumn(width="large",
                                                    help="e.g. Arrays, Trees, Graphs. Used to label each session."),
            WEAK_COL: st.column_config.TextColumn(width="medium", help="Topics you find hardest."),
        },
    )
    subjects, errors = sch.subjects_from_rows(df_to_rows(edited), cfg.start)
    for e in errors:
        st.error(e)

    if subjects:
        last_exam = max(s.exam_date for s in subjects)
        hours = sch.available_hours(cfg, last_exam)
        c1, c2, c3 = st.columns(3)
        c1.metric("Subjects", len(subjects))
        c2.metric("Days until last exam", (last_exam - cfg.start).days)
        c3.metric("Study hours available", f"{hours:g} h")
        if hours <= 0:
            st.error("There are no study hours before your last exam. Increase the daily hours in the sidebar.")
    else:
        st.info("Add at least one subject with an exam date after the plan start date.")

    if st.button("⚡ Generate timetable", type="primary", disabled=bool(errors) or not subjects):
        plan = sch.generate_plan(subjects, cfg)
        if not plan:
            st.error("Could not create a timetable. Check your study hours and exam dates.")
        else:
            ss.plan = plan
            ss.plan_subjects = subjects
            ss.plan_cfg = cfg
            clear_checkbox_state()
            st.success(f"Timetable ready: {len(plan)} sessions, {sum(s.hours for s in plan):g} study hours. "
                       "Open the **Timetable** tab 👉")

    with st.expander("How is the timetable built?"):
        st.markdown(
            """
For every day from the start date until the last exam:

1. **Free time** = weekday/weekend hours (0 on days off), in 30-minute slots.
2. **Weight per subject** = `difficulty × (1 + 7 / days_left)` → harder and closer exams get more time.
   Inside the revision window the weight is ×1.5.
3. The day's slots are shared between the top *N* subjects by weight (largest-remainder rounding).
4. Time is cut into sessions of at most 2 h, each assigned a topic. **Weak topics appear twice**, and
   revision days start with them.
5. **Auto-replan:** missed sessions are marked as moved, their topics are scheduled first, and subjects with a
   backlog get up to ×2 weight in the remaining days.
            """
        )


# --------------------------------------------------------------------------- #
# Tab 2: Timetable
# --------------------------------------------------------------------------- #
def _session_row(s: sch.Session) -> None:
    tag = "🔁 Revision" if s.kind == sch.KIND_REVISION else "📖 Study"
    label = f"**{s.subject}** — {s.topic} · {s.hours:g} h · {tag}"
    if s.rescheduled:
        st.markdown(f"~~{label}~~ ↪ moved by auto-replan")
        return
    st.checkbox(label, value=s.done, key=f"chk_{s.id}", on_change=_toggle, args=(s.id,))


def render_timetable() -> None:
    ss = st.session_state
    plan = ss.plan
    if not plan:
        st.info("No timetable yet. Add your subjects in the **Setup** tab and press **Generate timetable**.")
        return

    t = today()
    subjects = ss.plan_subjects
    names = [s.name for s in subjects]
    missed = sch.missed_sessions(plan, t)
    missed_ids = {s.id for s in missed}
    missed_hours = sum(s.hours for s in missed)

    left, right = st.columns([3, 2])
    with left:
        view = st.radio("Show", ["All days", "Upcoming", "Missed"], horizontal=True)
        picked = st.multiselect("Subjects", names, default=names)
    with right:
        if missed:
            st.warning(f"⚠️ {missed_hours:g} h across {len(missed)} sessions were missed.")
        else:
            st.success("No missed sessions. Keep it up!")
        if st.button("🔄 Auto-replan missed sessions", type="primary", disabled=not missed):
            ss.plan = sch.replan(plan, subjects, ss.plan_cfg, t)
            ss.notice = ("success", "Missed sessions were redistributed over your remaining days.")
            st.rerun()

    todays = [s for s in plan if s.date == t and not s.rescheduled]
    if todays:
        total_h = sum(s.hours for s in todays)
        done_h = sum(s.hours for s in todays if s.done)
        st.progress(done_h / total_h if total_h else 0.0, text=f"Today: {done_h:g} / {total_h:g} h done")

    by_date = defaultdict(list)
    for s in plan:
        by_date[s.date].append(s)
    exams = defaultdict(list)
    for sub in subjects:
        exams[sub.exam_date].append(sub.name)

    shown = 0
    for d in sorted(set(by_date) | set(exams)):
        day_sessions = [s for s in by_date.get(d, []) if s.subject in picked]
        day_exams = [n for n in exams.get(d, []) if n in picked]
        if view == "Upcoming" and d < t:
            continue
        if view == "Missed":
            day_sessions = [s for s in day_sessions if s.id in missed_ids]
            day_exams = []
            if not day_sessions:
                continue
        if not day_sessions and not day_exams:
            continue

        live = [s for s in day_sessions if not s.rescheduled]
        hours = sum(s.hours for s in live)
        n_done = sum(1 for s in live if s.done)
        if day_exams:
            icon = "📝"
        elif d == t:
            icon = "📍"
        elif any(s.id in missed_ids for s in live):
            icon = "⚠️"
        elif live and n_done == len(live):
            icon = "✅"
        else:
            icon = "🗓️"
        title = f"{icon} {d:%a, %d %b %Y} · {hours:g} h · {n_done}/{len(live)} done"
        if day_exams:
            title += " · EXAM: " + ", ".join(day_exams)

        with st.expander(title, expanded=(d == t)):
            for n in day_exams:
                st.error(f"📝 Exam day: **{n}**")
            for s in day_sessions:
                _session_row(s)
        shown += 1
    if shown == 0:
        st.info("Nothing to show for this filter.")


# --------------------------------------------------------------------------- #
# Tab 3: Progress
# --------------------------------------------------------------------------- #
def render_progress() -> None:
    ss = st.session_state
    plan = ss.plan
    if not plan:
        st.info("Generate a timetable first to see your progress.")
        return

    t = today()
    summary = sch.progress_summary(plan)
    total, done = summary["total"], summary["done"]
    missed_hours = sum(s.hours for s in sch.missed_sessions(plan, t))

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Planned", f"{total:g} h")
    c2.metric("Completed", f"{done:g} h")
    c3.metric("Remaining", f"{total - done:g} h")
    c4.metric("Missed", f"{missed_hours:g} h")
    frac = done / total if total else 0.0
    st.progress(min(max(frac, 0.0), 1.0), text=f"Overall progress: {frac:.0%}")

    st.subheader("By subject")
    for sub in ss.plan_subjects:
        d_h, t_h = summary["by_subject"].get(sub.name, (0.0, 0.0))
        f = d_h / t_h if t_h else 0.0
        days_left = (sub.exam_date - t).days
        when = f"exam in {days_left} day(s)" if days_left > 0 else ("exam today" if days_left == 0 else "exam over")
        st.progress(min(max(f, 0.0), 1.0), text=f"{sub.name} — {d_h:g}/{t_h:g} h ({f:.0%}) · {when}")

    live = [s for s in plan if not s.rescheduled]
    df = pd.DataFrame(
        [{"date": pd.Timestamp(s.date), "subject": s.subject, "hours": s.hours} for s in live]
    )
    if df.empty:
        return

    st.subheader("Daily study load")
    bar = (
        alt.Chart(df)
        .mark_bar()
        .encode(
            x=alt.X("yearmonthdate(date):T", title="Date"),
            y=alt.Y("sum(hours):Q", title="Hours"),
            color=alt.Color("subject:N", title="Subject"),
            tooltip=["subject:N", alt.Tooltip("sum(hours):Q", title="Hours")],
        )
        .properties(height=300, width="container")
    )
    st.altair_chart(bar)

    st.subheader("Weekly heatmap")
    daily = df.groupby("date", as_index=False)["hours"].sum()
    full = pd.DataFrame({"date": pd.date_range(daily["date"].min(), daily["date"].max())})
    full = full.merge(daily, on="date", how="left").fillna({"hours": 0.0})
    full["week_start"] = full["date"] - pd.to_timedelta(full["date"].dt.weekday, unit="D")
    full["Week of"] = full["week_start"].dt.strftime("%d %b")
    full["weekday"] = full["date"].dt.strftime("%a")
    week_order = list(full.sort_values("week_start")["Week of"].unique())
    base = alt.Chart(full).encode(
        x=alt.X("weekday:O", sort=WEEKDAYS, title=None),
        y=alt.Y("Week of:O", sort=week_order, title=None),
    )
    heat = base.mark_rect(cornerRadius=4).encode(
        color=alt.Color("hours:Q", scale=alt.Scale(scheme="greens"), title="Hours"),
        tooltip=[alt.Tooltip("date:T", title="Date"), alt.Tooltip("hours:Q", title="Hours")],
    )
    text = base.mark_text(fontSize=12).encode(text=alt.Text("hours:Q", format=".1f"))
    st.altair_chart((heat + text).properties(height=max(120, 48 * len(week_order)), width="container"))


# --------------------------------------------------------------------------- #
# Tab 4: Export
# --------------------------------------------------------------------------- #
def render_export() -> None:
    ss = st.session_state
    plan = ss.plan
    if not plan:
        st.info("Generate a timetable first to export it.")
        return

    st.subheader("Download")
    st.time_input("Daily study start time (for the calendar file)", key="cfg_time")
    c1, c2, c3 = st.columns(3)
    c1.download_button("⬇️ Timetable (CSV)", exporters.sessions_to_csv(plan),
                       file_name="study_timetable.csv", mime="text/csv")
    c2.download_button("📅 Calendar (.ics)",
                       exporters.sessions_to_ics(plan, ss.plan_subjects, ss.cfg_time),
                       file_name="study_plan.ics", mime="text/calendar")
    c3.download_button("💾 Save progress (JSON)",
                       storage.dump_state(ss.plan_subjects, ss.plan_cfg, plan),
                       file_name="study_planner_progress.json", mime="application/json")
    st.caption("The .ics file imports into Google Calendar, Outlook and Apple Calendar. "
               "Use the JSON file to resume your progress later from the sidebar.")

    st.subheader("Preview")
    st.dataframe(exporters.sessions_to_df(plan), hide_index=True)


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
def main() -> None:
    init_state()
    cfg = render_sidebar()

    st.title("📚 Smart Study Planner")
    st.caption("Enter subjects, exam dates and daily hours. Get a day-by-day revision timetable "
               "with a progress checklist and auto-replanning.")

    if st.session_state.notice:
        kind, msg = st.session_state.notice
        getattr(st, kind)(msg)
        st.session_state.notice = None

    tab_setup, tab_plan, tab_progress, tab_export = st.tabs(
        ["🛠️ Setup", "🗓️ Timetable", "📈 Progress", "📤 Export"]
    )
    with tab_setup:
        render_setup(cfg)
    with tab_plan:
        render_timetable()
    with tab_progress:
        render_progress()
    with tab_export:
        render_export()


main()
